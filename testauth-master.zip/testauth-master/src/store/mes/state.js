export default function() {
    return {
        auth: 0,
        messages: [],
        userName: "Александра",
        intervalCtx: null,
        lastMsgID: 0,
        messageText: "",
    }
}