<template>
  <q-page class="flex flex-center">
<h2>Сделайте пожалуйста аннотацию СЮДА!!!</h2>
  </q-page>
</template>

<script>
import { defineComponent } from 'vue';

export default defineComponent({
  name: 'PageIndex'
})
</script>
